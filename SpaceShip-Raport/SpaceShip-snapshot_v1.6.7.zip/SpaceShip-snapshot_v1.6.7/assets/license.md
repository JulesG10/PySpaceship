Artwork created by Luis Zuno (@ansimuz)


LICENSE:
You may use these assets in personal or commercial projects. You can modify these assets to suit your needs. You can re-distribute the file.
Credit no required but appreciated it.

Links

Twitter @ansimuz
Support my work at Patreon https://www.patreon.com/ansimuz
Buy my stuff https://ansimuz.itch.io/
Get more Free Assetslike these at: http://www.ansimuz.com


Pixel Shmup (1.1)

Created/distributed by Kenney (www.kenney.nl)
Creation date: 01-11-2021

		------------------------------

License: (Creative Commons Zero, CC0)
http://creativecommons.org/publicdomain/zero/1.0/
This content is free to use in personal, educational and commercial projects.
Support us by crediting Kenney or www.kenney.nl (this is not mandatory)
		------------------------------

Donate:   http://support.kenney.nl
Patreon:  http://patreon.com/kenney/
Follow on Twitter for updates:
http://twitter.com/KenneyNL
