

class GameChannel:

    CLIENT_ADD = "client_add"
    CLIENT_REMOVE = "client_remove"
    CLIENT_PAUSE = "client_pause"

    CLIENT_UPDATE = "client_update"
    
    CLIENT_BULLET = "client_bullet"
    CLIENT_UPDATE_BULLET = "client_update_bullet"
    CLIENT_BULLET_REMOVE = "client_bullet_remove"
    CLIENT_HIT = "client_hit"
    CLIENT_PLAYER = "client_player"

    CLIENT_SIZE = "client_size"

    TEST = "test"